const chat=document.getElementById("chat"),input=document.getElementById("message"),send=document.getElementById("send"),mic=document.getElementById("mic"),statusText=document.getElementById("statusText");let history=[];

function addMessage(role,text,typing=false){
 const row=document.createElement("div");row.className=`message ${role}`;
 if(role==="assistant"){const a=document.createElement("div");a.className="avatar";a.textContent="N";row.appendChild(a)}
 const bubble=document.createElement("div");bubble.className=`bubble ${typing?"typing":""}`;bubble.textContent=text;row.appendChild(bubble);chat.appendChild(row);chat.scrollTop=chat.scrollHeight;
 if(role==="assistant"&&!typing){const b=document.createElement("button");b.className="speak-btn";b.textContent="🔊 Listen";b.onclick=()=>speakText(text,b);bubble.appendChild(document.createElement("br"));bubble.appendChild(b)}
 return row;
}
async function checkStatus(){try{const r=await fetch("/api/status"),d=await r.json();statusText.textContent=d.configured?"AI READY":"API KEY NEEDED"}catch{statusText.textContent="OFFLINE"}}checkStatus();

async function ask(){
 const message=input.value.trim();if(!message)return;input.value="";input.style.height="auto";addMessage("user",message);const typing=addMessage("assistant","Thinking...",true);send.disabled=true;
 try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,history})});const d=await r.json();typing.remove();if(!r.ok)throw new Error(d.error||"Something went wrong.");addMessage("assistant",d.answer);history.push({role:"user",content:message},{role:"assistant",content:d.answer})}catch(e){typing.remove();addMessage("assistant","⚠️ "+e.message)}finally{send.disabled=false;input.focus()}
}

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;let recognition=null,listening=false;
if(SR){recognition=new SR();recognition.continuous=false;recognition.interimResults=true;recognition.lang="ha-NG";recognition.onstart=()=>{listening=true;mic.textContent="⏹️";mic.classList.add("listening")};recognition.onresult=e=>{let t="";for(let i=e.resultIndex;i<e.results.length;i++)t+=e.results[i][0].transcript;input.value=t;input.style.height="auto";input.style.height=Math.min(input.scrollHeight,140)+"px"};recognition.onend=()=>{listening=false;mic.textContent="🎙️";mic.classList.remove("listening")};recognition.onerror=()=>{listening=false;mic.textContent="🎙️";mic.classList.remove("listening")};mic.onclick=()=>listening?recognition.stop():recognition.start()}else{mic.disabled=true}

function speakText(text,button){if(!("speechSynthesis"in window))return;speechSynthesis.cancel();const s=new SpeechSynthesisUtterance(text);s.lang=/[ƙƘɓƁɗƊ]/.test(text)?"ha-NG":"en-US";s.rate=.95;s.onstart=()=>button.textContent="⏹️ Stop";s.onend=()=>button.textContent="🔊 Listen";speechSynthesis.speak(s)}

send.onclick=ask;input.onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();ask()}};input.oninput=()=>{input.style.height="auto";input.style.height=Math.min(input.scrollHeight,140)+"px"};document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{input.value=b.dataset.prompt+" ";input.focus()});