NA MUSAMMAN AI GLOBAL

1. Rename .env.example to .env
2. Put your OpenAI API key in .env. NEVER put the key in public/app.js.
3. Run: npm install
4. Run: npm start
5. Open: http://localhost:3000

Interface is English. The AI answers Hausa when the user asks in Hausa.
Voice input uses the browser microphone; voice output uses the device speech engine.
